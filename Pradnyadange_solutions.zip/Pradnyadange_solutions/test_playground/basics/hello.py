# yayy
print("Hello world")

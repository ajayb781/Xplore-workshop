# declare some variables

x = 10
y = 5

print(x+y) # come on think, this ain't javascript

num1 , num2 = 6 , 7

print(round(float(num1 / num2), 2))# huh this shouldnt output 0, as a bonus can u also round to 2 decimal places?

a , n = 1, 31

# for i in range(n):
# a = 2**n # can you replace this loop with a one liner?
a = (2**n) # ** replaces loop

# match the correct statements wrt bitwise operators

print("AND operator:", " & ")
print("OR operator:", " | ")
print("XOR operator:", " ^ ")
